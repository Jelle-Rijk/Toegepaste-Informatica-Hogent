package domein;

import java.time.LocalDate;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NamedQueries({
    @NamedQuery(name = "Onderhoudsbeurt.opDatum", 
        query = """
        		SELECT o FROM Onderhoudsbeurt o 
        		WHERE :datum BETWEEN o.begindatum AND o.einddatum
        		""")
})
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@EqualsAndHashCode(exclude = "id")
@Getter
@Setter
public class Onderhoudsbeurt {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
    private long id;
    
    private LocalDate begindatum;
    
    private LocalDate einddatum;
    
    @ManyToOne
    private Vervoermiddel vervoermiddel;

    public Onderhoudsbeurt(LocalDate begindatum, LocalDate einddatum, Vervoermiddel vervoermiddel) {
        this.begindatum = begindatum;
        this.einddatum = einddatum;
        this.vervoermiddel = vervoermiddel;
    }

    public boolean bevatDatum(LocalDate datum) {
        return !(datum.isBefore(begindatum)||datum.isAfter(einddatum));
    }

}
