package domein;

import jakarta.persistence.Entity;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@Entity
@NamedQueries({
    @NamedQuery(name = "Auto.alleAutosZonderOnderhoud", 
        query = """
        		SELECT a FROM Auto a 
        		WHERE a.onderhoudsbeurten IS EMPTY
        		"""),
    @NamedQuery(name = "Auto.alleAutosMetOnderhoud",
        query = """
        		SELECT a FROM Auto a 
        		WHERE a.onderhoudsbeurten IS NOT EMPTY
        		""")
})
//OF
/*@NamedQueries({
    @NamedQuery(name = "Auto.alleAutosZonderOnderhoud", 
        query = """
        		SELECT a FROM Auto a 
        		WHERE SIZE(a.onderhoudsbeurten) = 0
        		"""),
    @NamedQuery(name = "Auto.alleAutosMetOnderhoud",
        query = """
        		SELECT a FROM Auto a 
        		WHERE SIZE(a.onderhoudsbeurten) > 0
        		""")
})*/
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Auto extends Vervoermiddel {

    public Auto(String nummerplaat) {
        super(nummerplaat);
    }

    @Override
    public double geefVerkeersbelasting() {
        return 77.75;
        //volgens cilinderinhoud
    }
}
